// FRAME Photobooth — konfigurasi bisnis
// Ganti nomor berikut dengan nomor WhatsApp admin, gunakan format internasional tanpa + atau spasi.
// Contoh: 6281234567890
const WHATSAPP_ADMIN = "6281234567890";

document.addEventListener("DOMContentLoaded", () => {
  const menuToggle = document.querySelector(".menu-toggle");
  const navLinks = document.querySelector(".nav-links");

  menuToggle.addEventListener("click", () => {
    const isOpen = navLinks.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.textContent = isOpen ? "×" : "☰";
  });

  navLinks.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => {
      navLinks.classList.remove("open");
      menuToggle.setAttribute("aria-expanded", "false");
      menuToggle.textContent = "☰";
    });
  });

  document.querySelectorAll(".package-button").forEach(button => {
    button.addEventListener("click", () => {
      document.querySelector("#package").value = button.dataset.package;
      document.querySelector("#booking").scrollIntoView({ behavior: "smooth" });
    });
  });

  const dateInput = document.querySelector("#date");
  const today = new Date();
  const localToday = new Date(today.getTime() - today.getTimezoneOffset() * 60000)
    .toISOString().split("T")[0];
  dateInput.min = localToday;

  document.querySelector("#bookingForm").addEventListener("submit", event => {
    event.preventDefault();

    if (WHATSAPP_ADMIN === "6281234567890") {
      document.querySelector("#formHint").textContent =
        "Atur WHATSAPP_ADMIN di js/script.js menjadi nomor WhatsApp bisnis Anda sebelum menerima booking.";
      return;
    }

    const data = new FormData(event.currentTarget);
    const message = [
      "Halo FRAME Photobooth! Saya ingin booking.",
      `Nama: ${data.get("name")}`,
      `WhatsApp: ${data.get("phone")}`,
      `Jenis acara: ${data.get("event")}`,
      `Tanggal acara: ${data.get("date")}`,
      `Paket: ${data.get("package")}`,
      `Lokasi / catatan: ${data.get("notes") || "-"}`
    ].join("\\n");

    const url = `https://wa.me/${WHATSAPP_ADMIN}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank", "noopener,noreferrer");
    document.querySelector("#formHint").textContent = "WhatsApp terbuka dengan detail booking Anda.";
  });
});
